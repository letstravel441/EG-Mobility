package com.narendar.letstravel.travelfragments

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import android.widget.EditText
import android.widget.TimePicker
import com.narendar.letstravel.MapsActivity
import com.narendar.letstravel.R
import java.text.SimpleDateFormat
import java.util.*


class FindFragment : Fragment() {
    lateinit var btndate: Button
    lateinit var btnpassengers: Button
    var uday = 0
    var umonth = 0
    var uyear = 0
    var uhour = 0
    var umin = 0
    var formate = SimpleDateFormat("EEE ddMMM,yyyy hh:mm a",Locale.US)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_find, container, false)

        val pickuplocation = view.findViewById<EditText>(R.id.pickuplocation)
        val droplocation = view.findViewById<EditText>(R.id.droplocation)


            pickuplocation.setOnClickListener{
                val intent = Intent(this@FindFragment.context, MapsActivity::class.java)
                startActivity(intent)

            }


            droplocation.setOnClickListener{
                val intent = Intent(this@FindFragment.context, MapsActivity::class.java)
                startActivity(intent)

            }


        btndate = view.findViewById(R.id.date)
        btnpassengers = view.findViewById(R.id.passengers)
        val cal: Calendar = Calendar.getInstance()
        val date = formate.format(cal.time)
        btndate.text=date
        btndate.setOnClickListener {
            TimePickerDialog(
                view.context,
                TimePickerDialog.OnTimeSetListener { view: TimePicker?, hourOfDay, minute ->
                    uhour=hourOfDay
                    umin=minute
                    cal.set(Calendar.HOUR,hourOfDay)
                    cal.set(Calendar.MINUTE,minute)
                    val update = formate.format(cal.time)
                    btndate.text=update
                },
                cal.get(Calendar.HOUR),
                cal.get(Calendar.MINUTE),
                false
            ).show()
            DatePickerDialog(
                view.context  ,
                DatePickerDialog.OnDateSetListener { view: DatePicker?, myear: Int, mmonth: Int, mday: Int ->
                    uday=mday
                    umonth=mmonth
                    uyear=myear
                    cal.set(Calendar.YEAR,myear)
                    cal.set(Calendar.MONTH,mmonth)
                    cal.set(Calendar.DAY_OF_MONTH,mday)
                },
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_WEEK)
            ).show()


        }
        btnpassengers.setOnClickListener {

        }
        return view
    }
}